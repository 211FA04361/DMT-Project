#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, roc_curve, auc
import matplotlib.pyplot as plt
import numpy as np

# Load the dataset
data = pd.read_csv('combined_dataset .csv')  # Adjust the file path as needed

# Handle missing values if any
data.fillna(method='ffill', inplace=True)  # Forward fill missing values

# Label encoding for categorical variables
label_encoder = LabelEncoder()
for column in data.columns:
    if data[column].dtype == 'object':
        data[column] = label_encoder.fit_transform(data[column])

# Splitting the dataset into features and target variable
X = data.drop('label', axis=1)  # Features
y = data['label']  # Target variable

# Normalizing numerical features
scaler = StandardScaler()
X_normalized = scaler.fit_transform(X)

# Splitting the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_normalized, y, test_size=0.2, random_state=42)

# Support Vector Machine (SVM) model
svm_model = SVC(kernel='linear', probability=True)  # Set probability=True for ROC curve
svm_model.fit(X_train, y_train)
svm_predictions = svm_model.predict(X_test)
svm_accuracy = accuracy_score(y_test, svm_predictions)
print("Support Vector Machine (SVM) Accuracy: {:.2f}%".format(svm_accuracy * 100))
print(classification_report(y_test, svm_predictions))

# Random Forest model
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
rf_predictions = rf_model.predict(X_test)
rf_accuracy = accuracy_score(y_test, rf_predictions)
print("Random Forest Accuracy: {:.2f}%".format(rf_accuracy * 100))
print(classification_report(y_test, rf_predictions))

# Decision Tree model
dt_model = DecisionTreeClassifier(random_state=42)
dt_model.fit(X_train, y_train)
dt_predictions = dt_model.predict(X_test)
dt_accuracy = accuracy_score(y_test, dt_predictions)
print("Decision Tree Accuracy: {:.2f}%".format(dt_accuracy * 100))
print(classification_report(y_test, dt_predictions))

# Logistic Regression model
lr_model = LogisticRegression()
lr_model.fit(X_train, y_train)
lr_predictions = lr_model.predict(X_test)
lr_accuracy = accuracy_score(y_test, lr_predictions)
print("Logistic Regression Accuracy: {:.2f}%".format(lr_accuracy * 100))
print(classification_report(y_test, lr_predictions))

# Gradient Boosting Machine (GBM) model
gbm_model = GradientBoostingClassifier()
gbm_model.fit(X_train, y_train)
gbm_predictions = gbm_model.predict(X_test)
gbm_accuracy = accuracy_score(y_test, gbm_predictions)
print("Gradient Boosting Machine (GBM) Accuracy: {:.2f}%".format(gbm_accuracy * 100))
print(classification_report(y_test, gbm_predictions))

# Plotting the accuracy of models
models = ['SVM', 'Random Forest', 'Decision Tree', 'Logistic Regression', 'Gradient Boosting']
accuracies = [svm_accuracy, rf_accuracy, dt_accuracy, lr_accuracy, gbm_accuracy]

plt.figure(figsize=(8, 5))
plt.bar(models, accuracies, color=['blue', 'green', 'red', 'cyan', 'magenta'])
plt.xlabel('Models')
plt.ylabel('Accuracy')
plt.title('Model Accuracies')
plt.ylim(0, 1)
plt.grid(axis='y')
plt.show()

# Calculate and print risk percentage for each model
risks = 100 - np.array(accuracies) * 100

print("\nRisk Percentage for Each Model:")
for model, risk in zip(models, risks):
    print(f"{model}: {risk:.2f}%")

# Plot ROC curves for each model
plt.figure(figsize=(4, 3))
for name, model in zip(models, [svm_model, rf_model, dt_model, lr_model, gbm_model]):
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X_test)[:, 1]
    else:  # use decision function
        proba = model.decision_function(X_test)
    fpr, tpr, _ = roc_curve(y_test, proba)
    roc_auc = auc(fpr, tpr)
    plt.plot(fpr, tpr, lw=2, label=f'{name} (area = {roc_auc:.2f})')

plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curves')
plt.legend(loc="lower right")
plt.show()


# In[ ]:




